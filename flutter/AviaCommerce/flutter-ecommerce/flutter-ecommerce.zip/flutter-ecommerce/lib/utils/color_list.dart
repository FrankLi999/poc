import 'package:flutter/material.dart';

List<Color> colorList = [
  Colors.pink.shade200,
  Colors.cyan.shade200,
  Colors.orange.shade300,
  Colors.indigo.shade200,
  Colors.green.shade300,
  Colors.red.shade300,
  Colors.pink.shade200,
  Colors.cyan.shade200,
  Colors.orange.shade300,
  Colors.indigo.shade200,
  Colors.green.shade300,
  Colors.red.shade300,
  Colors.pink.shade200,
  Colors.cyan.shade200,
  Colors.orange.shade300,
  Colors.indigo.shade200,
  Colors.green.shade300,
  Colors.red.shade300
];
