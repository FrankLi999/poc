class DefaultConfig {
  static const String PAYUBIZ_SALT = 'eCwWELxi';
  static const String PAYUBZ_KEY = 'gtKFFx';
  static const String APP_NAME = 'Angularspree';
}

class Environment {
  static const API_ENDPOINT = 'http://localhost:3000/';
}