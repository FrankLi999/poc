class PaymentMethod {
  final int id;
  final String name;

  PaymentMethod({
    this.id,
    this.name,
  });
}
