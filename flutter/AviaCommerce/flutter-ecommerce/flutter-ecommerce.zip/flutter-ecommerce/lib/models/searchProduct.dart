class SearchProduct {
  String name;
  String image;
  String price;
  String currencySymbol;
  String slug;
  SearchProduct(
      {this.currencySymbol, this.image, this.price, this.name, this.slug});
}
