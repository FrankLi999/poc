class Brand {
  final String name;
  final int id;

  Brand({this.id, this.name});
}
