class OptionType {
  final int id;
  final String name;
  final String presentation;
  final int position;

  OptionType({this.id, this.name, this.position, this.presentation});
}
